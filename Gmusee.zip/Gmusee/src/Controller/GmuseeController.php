<?php

namespace App\Controller;

use App\Entity\Gmusee;
use App\Form\GmuseeType;
use App\Repository\GmuseeRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/gmusee")
 */
class GmuseeController extends AbstractController
{
    /**
     * @Route("/", name="gmusee_index", methods={"GET"})
     */
    public function index(GmuseeRepository $gmuseeRepository): Response
    {
        return $this->render('gmusee/index.html.twig', [
            'gmusees' => $gmuseeRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="gmusee_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $gmusee = new Gmusee();
        $form = $this->createForm(GmuseeType::class, $gmusee);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($gmusee);
            $entityManager->flush();

            return $this->redirectToRoute('gmusee_index');
        }

        return $this->render('gmusee/new.html.twig', [
            'gmusee' => $gmusee,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="gmusee_show", methods={"GET"})
     */
    public function show(Gmusee $gmusee): Response
    {
        return $this->render('gmusee/show.html.twig', [
            'gmusee' => $gmusee,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="gmusee_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Gmusee $gmusee): Response
    {
        $form = $this->createForm(GmuseeType::class, $gmusee);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('gmusee_index');
        }

        return $this->render('gmusee/edit.html.twig', [
            'gmusee' => $gmusee,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="gmusee_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Gmusee $gmusee): Response
    {
        if ($this->isCsrfTokenValid('delete' . $gmusee->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($gmusee);
            $entityManager->flush();
        }

        return $this->redirectToRoute('gmusee_index');
    }

    public function recherchebynomAction() : Response
    {
        $em=$this->getDoctrine () -> getManager();
    $gmusee = $em->getRepository ( className: Gmusee::class) ->findAll() ;
       return $this->render('gmusee/recherche.html.twig',array
       ('gmusee' => $gmusee));
}
}
